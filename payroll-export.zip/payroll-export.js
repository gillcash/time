/**
 * Payroll Export — CSV + PDF generation for approved timesheets.
 *
 * Triggered via POST /api/time/approval/:week/export (manager/admin)
 * or auto-triggered after weekly approval.
 *
 * Generates:
 *   1. CSV — one row per employee with daily hours, totals, OT
 *   2. PDF — formatted timesheet summary with company header,
 *      employee table, overtime breakdown, approval signature
 *
 * Emails both as attachments to the accountant_email from app_config.
 * Falls back to console.log when RESEND_API_KEY is unset.
 *
 * Updates timesheet_approvals.csv_sent_at / pdf_sent_at on success.
 */

import { DateTime } from 'luxon';

const TZ = 'America/Moncton';
const RESEND_API_KEY = process.env.RESEND_API_KEY || '';
const MAILER_FROM = process.env.TIME_MAILER_FROM || 'noreply@example.com';

// ── CSV Generation ────────────────────────────────────────────

/**
 * Generate a payroll CSV string from weekly hours data.
 * @param {object} params
 * @param {string} params.payWeekStart — YYYY-MM-DD Monday
 * @param {string} params.payWeekEnd — YYYY-MM-DD Sunday
 * @param {Array} params.employees — rows from v_weekly_hours + overtime
 * @param {string} params.companyName
 * @returns {string} CSV content
 */
export function generatePayrollCSV({ payWeekStart, payWeekEnd, employees, companyName }) {
  const headers = [
    'Employee ID',
    'Employee Name',
    'Department',
    'Job Title',
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
    'Total Hours',
    'Regular Hours',
    'OT Hours',
    'Hourly Rate',
    'OT Rate',
    'Lunch Deductions',
    'Flags'
  ];

  const rows = [headers.join(',')];

  // Metadata row
  rows.push(`# Pay Period: ${payWeekStart} to ${payWeekEnd}`);
  rows.push(`# Company: ${csvEscape(companyName)}`);
  rows.push(`# Generated: ${DateTime.now().setZone(TZ).toFormat('yyyy-MM-dd HH:mm:ss ZZZZ')}`);
  rows.push(''); // blank line before data

  // Re-add headers after metadata
  rows.push(headers.join(','));

  for (const emp of employees) {
    const totalHours = minutesToHours(emp.total_net_minutes || 0);
    const regularHours = minutesToHours(emp.regular_minutes ?? emp.total_net_minutes ?? 0);
    const otHours = minutesToHours(emp.overtime_minutes || 0);

    const row = [
      csvEscape(emp.employee_code || ''),
      csvEscape(emp.employee_name || ''),
      csvEscape(emp.department || ''),
      csvEscape(emp.job_title || ''),
      minutesToHours(emp.mon_minutes || 0),
      minutesToHours(emp.tue_minutes || 0),
      minutesToHours(emp.wed_minutes || 0),
      minutesToHours(emp.thu_minutes || 0),
      minutesToHours(emp.fri_minutes || 0),
      minutesToHours(emp.sat_minutes || 0),
      minutesToHours(emp.sun_minutes || 0),
      totalHours,
      regularHours,
      otHours,
      emp.hourly_rate != null ? emp.hourly_rate.toFixed(2) : '',
      emp.overtime_rate != null ? emp.overtime_rate.toFixed(2) : '',
      emp.lunch_deduction_count || 0,
      emp.flagged_count || 0
    ];

    rows.push(row.join(','));
  }

  // Summary row
  const totalAll = employees.reduce((s, e) => s + (e.total_net_minutes || 0), 0);
  const totalOT = employees.reduce((s, e) => s + (e.overtime_minutes || 0), 0);
  rows.push('');
  rows.push([
    '', 'TOTALS', '', '',
    '', '', '', '', '', '', '',
    minutesToHours(totalAll),
    minutesToHours(totalAll - totalOT),
    minutesToHours(totalOT),
    '', '', '', ''
  ].join(','));

  return rows.join('\n');
}

// ── PDF Generation (PDFKit) ───────────────────────────────────

/**
 * Generate a payroll PDF as a Buffer.
 * Uses PDFKit — must be installed: npm install pdfkit
 * @param {object} params — same as generatePayrollCSV
 * @returns {Promise<Buffer>} PDF buffer
 */
export async function generatePayrollPDF({ payWeekStart, payWeekEnd, employees, companyName, approvedBy, approvedAt }) {
  // Dynamic import so the module doesn't crash if pdfkit isn't installed
  const PDFDocument = (await import('pdfkit')).default;

  return new Promise((resolve, reject) => {
    const chunks = [];
    const doc = new PDFDocument({
      size: 'LETTER',
      layout: 'landscape',
      margins: { top: 40, bottom: 40, left: 40, right: 40 }
    });

    doc.on('data', chunk => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const pageWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;

    // ── Header ──────────────────────────────────────────────
    doc.fontSize(18).font('Helvetica-Bold')
      .text(companyName || 'Time', { align: 'left' });

    doc.fontSize(10).font('Helvetica')
      .text('Weekly Timesheet Summary', { align: 'left' });

    doc.moveDown(0.5);

    // Pay period info
    const weekStartFmt = DateTime.fromISO(payWeekStart).toFormat('MMMM d, yyyy');
    const weekEndFmt = DateTime.fromISO(payWeekEnd).toFormat('MMMM d, yyyy');
    doc.fontSize(11).font('Helvetica-Bold')
      .text(`Pay Period: ${weekStartFmt} — ${weekEndFmt}`);
    doc.fontSize(9).font('Helvetica')
      .text(`Generated: ${DateTime.now().setZone(TZ).toFormat('MMMM d, yyyy h:mm a ZZZZ')}`);

    doc.moveDown(1);

    // ── Table Header ────────────────────────────────────────
    const cols = [
      { label: 'Employee',  width: 130 },
      { label: 'ID',        width: 55 },
      { label: 'Mon',       width: 42 },
      { label: 'Tue',       width: 42 },
      { label: 'Wed',       width: 42 },
      { label: 'Thu',       width: 42 },
      { label: 'Fri',       width: 42 },
      { label: 'Sat',       width: 42 },
      { label: 'Sun',       width: 42 },
      { label: 'Total',     width: 50 },
      { label: 'Reg',       width: 45 },
      { label: 'OT',        width: 45 },
      { label: 'Flags',     width: 40 }
    ];

    const tableLeft = doc.page.margins.left;
    let y = doc.y;
    const rowHeight = 18;
    const headerHeight = 22;

    // Header background
    doc.save();
    doc.rect(tableLeft, y, pageWidth, headerHeight).fill('#1a1d24');
    doc.restore();

    // Header text
    let x = tableLeft + 4;
    doc.fontSize(8).font('Helvetica-Bold').fillColor('#ffffff');
    for (const col of cols) {
      doc.text(col.label, x, y + 6, { width: col.width - 4, align: 'left' });
      x += col.width;
    }
    doc.fillColor('#000000');

    y += headerHeight;

    // ── Table Rows ──────────────────────────────────────────
    let alternate = false;
    for (const emp of employees) {
      // Check if we need a new page
      if (y + rowHeight > doc.page.height - doc.page.margins.bottom - 80) {
        doc.addPage();
        y = doc.page.margins.top;

        // Repeat header on new page
        doc.save();
        doc.rect(tableLeft, y, pageWidth, headerHeight).fill('#1a1d24');
        doc.restore();

        x = tableLeft + 4;
        doc.fontSize(8).font('Helvetica-Bold').fillColor('#ffffff');
        for (const col of cols) {
          doc.text(col.label, x, y + 6, { width: col.width - 4, align: 'left' });
          x += col.width;
        }
        doc.fillColor('#000000');
        y += headerHeight;
        alternate = false;
      }

      // Alternating row background
      if (alternate) {
        doc.save();
        doc.rect(tableLeft, y, pageWidth, rowHeight).fill('#f7f8fa');
        doc.restore();
      }
      alternate = !alternate;

      // Flag row with amber left border
      if ((emp.flagged_count || 0) > 0) {
        doc.save();
        doc.rect(tableLeft, y, 3, rowHeight).fill('#f59e0b');
        doc.restore();
      }

      // Zero-hours row with red left border
      if ((emp.total_net_minutes || 0) === 0) {
        doc.save();
        doc.rect(tableLeft, y, 3, rowHeight).fill('#ef4444');
        doc.restore();
      }

      x = tableLeft + 4;
      doc.fontSize(8).font('Helvetica');

      const totalH = minutesToHours(emp.total_net_minutes || 0);
      const regH = minutesToHours(emp.regular_minutes ?? emp.total_net_minutes ?? 0);
      const otH = minutesToHours(emp.overtime_minutes || 0);

      const values = [
        truncate(emp.employee_name || '', 22),
        emp.employee_code || '',
        minutesToHours(emp.mon_minutes || 0),
        minutesToHours(emp.tue_minutes || 0),
        minutesToHours(emp.wed_minutes || 0),
        minutesToHours(emp.thu_minutes || 0),
        minutesToHours(emp.fri_minutes || 0),
        minutesToHours(emp.sat_minutes || 0),
        minutesToHours(emp.sun_minutes || 0),
        totalH,
        regH,
        otH,
        String(emp.flagged_count || 0)
      ];

      for (let i = 0; i < cols.length; i++) {
        // Bold for total/reg/OT columns
        if (i >= 9 && i <= 11) doc.font('Helvetica-Bold');
        else doc.font('Helvetica');

        // Red for OT > 0
        if (i === 11 && (emp.overtime_minutes || 0) > 0) doc.fillColor('#c2410c');
        else doc.fillColor('#000000');

        doc.text(values[i], x, y + 5, { width: cols[i].width - 4, align: 'left' });
        x += cols[i].width;
      }

      y += rowHeight;
    }

    // ── Totals Row ──────────────────────────────────────────
    const totalAll = employees.reduce((s, e) => s + (e.total_net_minutes || 0), 0);
    const totalOT = employees.reduce((s, e) => s + (e.overtime_minutes || 0), 0);
    const totalReg = totalAll - totalOT;

    y += 2;
    doc.save();
    doc.rect(tableLeft, y, pageWidth, headerHeight).fill('#282d38');
    doc.restore();

    x = tableLeft + 4;
    doc.fontSize(9).font('Helvetica-Bold').fillColor('#ffffff');
    doc.text(`TOTALS (${employees.length} employees)`, x, y + 6, { width: cols[0].width + cols[1].width - 4 });

    // Skip to total column position
    let totalX = tableLeft + 4;
    for (let i = 0; i < 9; i++) totalX += cols[i].width;
    doc.text(minutesToHours(totalAll), totalX, y + 6, { width: cols[9].width - 4 });
    totalX += cols[9].width;
    doc.text(minutesToHours(totalReg), totalX, y + 6, { width: cols[10].width - 4 });
    totalX += cols[10].width;
    if (totalOT > 0) doc.fillColor('#fb923c');
    doc.text(minutesToHours(totalOT), totalX, y + 6, { width: cols[11].width - 4 });

    doc.fillColor('#000000');
    y += headerHeight + 12;

    // ── Overtime Summary ────────────────────────────────────
    const otEmployees = employees.filter(e => (e.overtime_minutes || 0) > 0);
    if (otEmployees.length > 0) {
      doc.fontSize(11).font('Helvetica-Bold')
        .text('Overtime Summary', tableLeft, y);
      y += 16;

      doc.fontSize(9).font('Helvetica');
      for (const emp of otEmployees) {
        const otH = minutesToHours(emp.overtime_minutes);
        const rate = emp.overtime_rate != null ? `$${emp.overtime_rate.toFixed(2)}/hr` : 'N/A';
        doc.text(
          `${emp.employee_name} (${emp.employee_code}): ${otH}h OT at ${rate}`,
          tableLeft + 8, y
        );
        y += 14;
      }
      y += 8;
    }

    // ── Approval Footer ─────────────────────────────────────
    doc.moveTo(tableLeft, y).lineTo(tableLeft + pageWidth, y).stroke('#d8dce4');
    y += 12;

    if (approvedBy) {
      doc.fontSize(9).font('Helvetica')
        .text(`Approved by: ${approvedBy}`, tableLeft, y);
      y += 14;
    }
    if (approvedAt) {
      const approvedFmt = DateTime.fromISO(approvedAt, { zone: 'utc' })
        .setZone(TZ).toFormat('MMMM d, yyyy h:mm a ZZZZ');
      doc.fontSize(9).font('Helvetica')
        .text(`Approved at: ${approvedFmt}`, tableLeft, y);
      y += 14;
    }

    doc.fontSize(8).font('Helvetica').fillColor('#5a6377')
      .text(
        'This report was generated automatically from approved timesheet data. ' +
        'Overtime calculated per NB Employment Standards Act (44 hr/week threshold, 1.5× NB minimum wage).',
        tableLeft, y + 8, { width: pageWidth }
      );

    doc.end();
  });
}

// ── Email Delivery ────────────────────────────────────────────

/**
 * Email the CSV + PDF to the accountant via Resend.
 * Falls back to console.log when RESEND_API_KEY is unset.
 *
 * @param {object} params
 * @param {string} params.to — accountant email
 * @param {string} params.payWeekStart
 * @param {string} params.payWeekEnd
 * @param {string} params.companyName
 * @param {string} params.csvContent — CSV string
 * @param {Buffer} params.pdfBuffer — PDF buffer
 * @returns {Promise<{ ok: boolean, fallback?: boolean, error?: string }>}
 */
export async function emailPayrollExport({ to, payWeekStart, payWeekEnd, companyName, csvContent, pdfBuffer }) {
  const weekLabel = DateTime.fromISO(payWeekStart).toFormat('MMM d');
  const weekEndLabel = DateTime.fromISO(payWeekEnd).toFormat('MMM d, yyyy');
  const subject = `${companyName || 'Time'} — Payroll Export: ${weekLabel} – ${weekEndLabel}`;
  const filePrefix = `payroll-${payWeekStart}`;

  if (!RESEND_API_KEY) {
    console.log('=== PAYROLL EXPORT (no RESEND_API_KEY — console only) ===');
    console.log(`  To: ${to}`);
    console.log(`  Subject: ${subject}`);
    console.log(`  CSV: ${csvContent.split('\n').length} lines`);
    console.log(`  PDF: ${pdfBuffer.length} bytes`);
    console.log('=========================================================');
    return { ok: true, fallback: true };
  }

  if (!to) {
    return { ok: false, error: 'No accountant email configured' };
  }

  try {
    const resp = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: MAILER_FROM,
        to: [to],
        subject,
        html: `
          <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 600px; margin: 0 auto; padding: 32px;">
            <h2 style="color: #181A1D; margin-bottom: 8px;">${companyName || 'Time'}</h2>
            <p style="color: #555; margin-bottom: 16px;">Weekly payroll export for the pay period <strong>${weekLabel} – ${weekEndLabel}</strong>.</p>
            <div style="background: #f7f8fa; border: 1px solid #d8dce4; border-left: 3px solid #f97316; border-radius: 4px; padding: 16px; margin-bottom: 24px;">
              <p style="margin: 0; font-size: 14px; color: #333;">Attached files:</p>
              <ul style="margin: 8px 0 0; padding-left: 20px; color: #555; font-size: 14px;">
                <li><strong>${filePrefix}.csv</strong> — Tabular data for payroll import</li>
                <li><strong>${filePrefix}.pdf</strong> — Formatted timesheet summary for records</li>
              </ul>
            </div>
            <p style="color: #999; font-size: 12px;">
              This email was sent automatically upon timesheet approval.
              Overtime calculated per NB Employment Standards Act.
            </p>
          </div>
        `,
        attachments: [
          {
            filename: `${filePrefix}.csv`,
            content: Buffer.from(csvContent, 'utf-8').toString('base64')
          },
          {
            filename: `${filePrefix}.pdf`,
            content: pdfBuffer.toString('base64')
          }
        ]
      })
    });

    if (!resp.ok) {
      const body = await resp.text();
      console.error('Resend payroll email error:', resp.status, body);
      return { ok: false, error: `Resend API error: ${resp.status}` };
    }

    const data = await resp.json();
    return { ok: true, messageId: data.id };
  } catch (err) {
    console.error('Payroll email send failed:', err.message);
    return { ok: false, error: err.message };
  }
}

// ── Orchestrator ──────────────────────────────────────────────

/**
 * Full export pipeline: query data → generate CSV + PDF → email → update DB.
 *
 * @param {function} getTimeDb — factory returning better-sqlite3 Database
 * @param {string} payWeekStart — YYYY-MM-DD Monday
 * @param {number} supervisorId — who approved
 * @returns {Promise<{ ok: boolean, csv?: string, pdf?: Buffer, email?: object, error?: string }>}
 */
export async function runPayrollExport(getTimeDb, payWeekStart, supervisorId) {
  let db;
  try {
    db = getTimeDb();
    const config = loadConfig(db);
    const companyName = config.company_name || 'Time';
    const accountantEmail = config.accountant_email || '';
    const payWeekEnd = DateTime.fromISO(payWeekStart).plus({ days: 6 }).toISODate();

    // Get the approval record
    const approval = db.prepare(`
      SELECT ta.*, 
             COALESCE(e.display_name, e.legal_given_name || ' ' || e.legal_surname) AS approver_name
      FROM timesheet_approvals ta
      JOIN employees e ON e.id = ta.supervisor_id
      WHERE ta.supervisor_id = ? AND ta.pay_week_start = ? AND ta.status = 'approved'
    `).get(supervisorId, payWeekStart);

    if (!approval) {
      return { ok: false, error: 'No approved timesheet found for this week/supervisor' };
    }

    // Get employee hours with overtime calculations
    const weeklyData = db.prepare(`
      SELECT wh.*,
             e.department, e.job_title, e.hourly_rate,
             ot.regular_minutes, ot.overtime_minutes, ot.nb_minimum_wage, ot.overtime_rate
      FROM v_weekly_hours wh
      JOIN employees e ON e.id = wh.employee_id
      LEFT JOIN overtime_calculations ot 
        ON ot.employee_id = wh.employee_id AND ot.pay_week_start = wh.pay_week_start
      WHERE wh.pay_week_start = ?
      ORDER BY e.legal_surname, e.legal_given_name
    `).all(payWeekStart);

    // Also count lunch deductions per employee
    for (const emp of weeklyData) {
      const lunchRow = db.prepare(`
        SELECT COUNT(*) AS cnt FROM time_entries
        WHERE employee_id = ? AND pay_week_start = ? AND lunch_deducted = 1
          AND status IN ('closed', 'approved')
      `).get(emp.employee_id, payWeekStart);
      emp.lunch_deduction_count = lunchRow.cnt;
    }

    // Include zero-hours employees (active employees supervised by this supervisor with no entries)
    const zeroHoursEmployees = db.prepare(`
      SELECT e.id AS employee_id, 
             e.employee_id AS employee_code,
             COALESCE(e.display_name, e.legal_given_name || ' ' || e.legal_surname) AS employee_name,
             e.department, e.job_title, e.hourly_rate, e.supervisor_id
      FROM employees e
      WHERE e.active = 1
        AND e.id NOT IN (
          SELECT DISTINCT employee_id FROM time_entries WHERE pay_week_start = ?
        )
    `).all(payWeekStart);

    for (const emp of zeroHoursEmployees) {
      weeklyData.push({
        ...emp,
        total_net_minutes: 0, total_hours: 0, entry_count: 0,
        flagged_count: 0, pending_lunch_overrides: 0,
        mon_minutes: 0, tue_minutes: 0, wed_minutes: 0, thu_minutes: 0,
        fri_minutes: 0, sat_minutes: 0, sun_minutes: 0,
        regular_minutes: 0, overtime_minutes: 0,
        nb_minimum_wage: null, overtime_rate: null,
        lunch_deduction_count: 0
      });
    }

    // Sort all employees by name
    weeklyData.sort((a, b) =>
      (a.employee_name || '').localeCompare(b.employee_name || '')
    );

    // Generate CSV
    const csvContent = generatePayrollCSV({
      payWeekStart, payWeekEnd,
      employees: weeklyData,
      companyName
    });

    // Generate PDF
    const pdfBuffer = await generatePayrollPDF({
      payWeekStart, payWeekEnd,
      employees: weeklyData,
      companyName,
      approvedBy: approval.approver_name,
      approvedAt: approval.approved_at
    });

    // Email
    let emailResult = { ok: false, error: 'No accountant email configured' };
    if (accountantEmail) {
      emailResult = await emailPayrollExport({
        to: accountantEmail,
        payWeekStart, payWeekEnd,
        companyName,
        csvContent, pdfBuffer
      });
    } else {
      console.log('[payroll-export] No accountant_email configured — skipping email delivery');
      // Still log to console for dev visibility
      emailResult = await emailPayrollExport({
        to: null,
        payWeekStart, payWeekEnd,
        companyName,
        csvContent, pdfBuffer
      });
    }

    // Update approval record with send timestamps
    if (emailResult.ok) {
      const now = new Date().toISOString();
      db.prepare(`
        UPDATE timesheet_approvals 
        SET csv_sent_at = ?, pdf_sent_at = ?
        WHERE id = ?
      `).run(now, now, approval.id);
    }

    return {
      ok: true,
      employeeCount: weeklyData.length,
      csvLines: csvContent.split('\n').length,
      pdfBytes: pdfBuffer.length,
      email: emailResult
    };
  } catch (err) {
    console.error('[payroll-export] Export failed:', err.message);
    return { ok: false, error: err.message };
  } finally {
    db?.close();
  }
}

// ── Helpers ───────────────────────────────────────────────────

function minutesToHours(mins) {
  if (mins == null || mins === 0) return '0.00';
  return (mins / 60).toFixed(2);
}

function csvEscape(value) {
  if (value == null) return '';
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return '"' + str.replace(/"/g, '""') + '"';
  }
  return str;
}

function truncate(str, max) {
  if (!str) return '';
  return str.length > max ? str.slice(0, max - 1) + '…' : str;
}

function loadConfig(db) {
  const rows = db.prepare('SELECT key, value FROM app_config').all();
  const config = {};
  for (const row of rows) config[row.key] = row.value;
  return config;
}
