# Payroll Export — Integration Guide

> Phase 9: CSV + PDF generation from approved timesheets, emailed to accountant via Resend.

## Files to Add/Modify

### 1. New file: `deploy/api/payroll-export.js`
Copy `payroll-export.js` into `deploy/api/`. No modifications needed.

### 2. Update: `deploy/api/package.json`
Add `pdfkit` dependency:
```json
"pdfkit": "^0.16.0"
```

### 3. Update: `deploy/api/time-routes.js`

**Add import at top (after the existing imports):**
```js
import { runPayrollExport } from './payroll-export.js';
```

**Add two new routes** after the lunch-override route (line ~1314) and before the NOTIFICATIONS section:

```js
  // POST /api/time/approval/:week/export — generate + email payroll CSV + PDF
  router.post('/api/time/approval/:week/export',
    requireTimeAuth,
    requireTimeRole('supervisor', 'manager', 'admin'),
    async (req, res) => {
      try {
        const week = req.params.week;
        if (!validateWeekParam(week, res)) return;

        const result = await runPayrollExport(getTimeDb, week, req.timeUser.id);

        if (!result.ok) {
          return res.status(400).json({ error: result.error });
        }

        let db;
        try {
          db = getTimeDb();
          auditLog(db, {
            actorId: req.timeUser.id,
            action: 'payroll_export',
            targetType: 'pay_week',
            targetId: week,
            details: {
              employeeCount: result.employeeCount,
              csvLines: result.csvLines,
              pdfBytes: result.pdfBytes,
              emailSent: result.email?.ok || false
            },
            ipAddress: req.ip
          });
        } finally {
          db?.close();
        }

        res.json({
          ok: true,
          employeeCount: result.employeeCount,
          csvLines: result.csvLines,
          pdfBytes: result.pdfBytes,
          email: {
            sent: result.email?.ok || false,
            fallback: result.email?.fallback || false,
            error: result.email?.error || null
          }
        });
      } catch (err) {
        console.error('POST /api/time/approval/:week/export error:', err.message);
        res.status(500).json({ error: err.message });
      }
    }
  );

  // GET /api/time/approval/:week/export/download — direct CSV or PDF download
  router.get('/api/time/approval/:week/export/download',
    requireTimeAuth,
    requireTimeRole('supervisor', 'manager', 'admin'),
    async (req, res) => {
      try {
        const week = req.params.week;
        if (!validateWeekParam(week, res)) return;

        const format = req.query.format || 'csv';
        if (!['csv', 'pdf'].includes(format)) {
          return res.status(400).json({ error: 'format must be csv or pdf' });
        }

        let db;
        try {
          db = getTimeDb();
          const config = {};
          for (const row of db.prepare('SELECT key, value FROM app_config').all()) {
            config[row.key] = row.value;
          }

          const approval = db.prepare(`
            SELECT ta.*,
                   COALESCE(e.display_name, e.legal_given_name || ' ' || e.legal_surname) AS approver_name
            FROM timesheet_approvals ta
            JOIN employees e ON e.id = ta.supervisor_id
            WHERE ta.supervisor_id = ? AND ta.pay_week_start = ? AND ta.status = 'approved'
          `).get(req.timeUser.id, week);

          if (!approval) {
            return res.status(400).json({ error: 'No approved timesheet found' });
          }

          const payWeekEnd = DateTime.fromISO(week).plus({ days: 6 }).toISODate();
          const companyName = config.company_name || 'Time';

          const weeklyData = db.prepare(`
            SELECT wh.*,
                   e.department, e.job_title, e.hourly_rate,
                   ot.regular_minutes, ot.overtime_minutes, ot.nb_minimum_wage, ot.overtime_rate
            FROM v_weekly_hours wh
            JOIN employees e ON e.id = wh.employee_id
            LEFT JOIN overtime_calculations ot
              ON ot.employee_id = wh.employee_id AND ot.pay_week_start = wh.pay_week_start
            WHERE wh.pay_week_start = ?
            ORDER BY e.legal_surname, e.legal_given_name
          `).all(week);

          for (const emp of weeklyData) {
            const r = db.prepare(`
              SELECT COUNT(*) AS cnt FROM time_entries
              WHERE employee_id = ? AND pay_week_start = ? AND lunch_deducted = 1
                AND status IN ('closed', 'approved')
            `).get(emp.employee_id, week);
            emp.lunch_deduction_count = r.cnt;
          }

          const { generatePayrollCSV, generatePayrollPDF } = await import('./payroll-export.js');
          const filePrefix = `payroll-${week}`;

          if (format === 'csv') {
            const csv = generatePayrollCSV({
              payWeekStart: week, payWeekEnd,
              employees: weeklyData, companyName
            });
            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', `attachment; filename="${filePrefix}.csv"`);
            return res.send(csv);
          } else {
            const pdf = await generatePayrollPDF({
              payWeekStart: week, payWeekEnd,
              employees: weeklyData, companyName,
              approvedBy: approval.approver_name,
              approvedAt: approval.approved_at
            });
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', `attachment; filename="${filePrefix}.pdf"`);
            return res.send(pdf);
          }
        } finally {
          db?.close();
        }
      } catch (err) {
        console.error('GET export/download error:', err.message);
        res.status(500).json({ error: err.message });
      }
    }
  );
```

### 4. Auto-trigger on approval (optional)

Add this fire-and-forget call at the end of the `POST /api/time/approval/:week/approve`
route, right before `res.json({ ok: true, approvalId })`:

```js
        // Fire-and-forget: generate + email payroll export
        runPayrollExport(getTimeDb, week, user.id).catch(err =>
          console.error('[payroll-export] Auto-trigger failed:', err.message)
        );

        res.json({ ok: true, approvalId });
```

### 5. Update: `deploy/api/Dockerfile`
No changes needed — `npm install --production` will pick up `pdfkit` from the
updated package.json.

### 6. Update: `CLAUDE.md` API endpoints table
Add:
```
| POST   | `/api/time/approval/:week/export`          | Generate + email CSV/PDF   |
| GET    | `/api/time/approval/:week/export/download` | Download CSV or PDF        |
```

---

## API Reference

### POST `/api/time/approval/:week/export`
**Auth:** supervisor, manager, admin
**Description:** Generates CSV + PDF from approved timesheet data and emails both
to the `accountant_email` from app_config. Updates `csv_sent_at`/`pdf_sent_at`
on the approval record.

**Response:**
```json
{
  "ok": true,
  "employeeCount": 25,
  "csvLines": 32,
  "pdfBytes": 48230,
  "email": {
    "sent": true,
    "fallback": false,
    "error": null
  }
}
```

When `RESEND_API_KEY` is unset, `email.fallback` is `true` and the export is
logged to console instead.

When `accountant_email` in app_config is empty, `email.sent` is `false` with
`email.error: "No accountant email configured"`. The CSV + PDF are still generated
and the response includes their sizes.

### GET `/api/time/approval/:week/export/download?format=csv|pdf`
**Auth:** supervisor, manager, admin
**Description:** Direct file download — returns the CSV or PDF as an attachment.
Use for supervisor-initiated downloads from the approval screen.

---

## CSV Format

```
# Pay Period: 2026-03-09 to 2026-03-15
# Company: Grey Rock Materials
# Generated: 2026-03-17 12:30:00 ADT

Employee ID,Employee Name,Department,Job Title,Mon,Tue,Wed,Thu,Fri,Sat,Sun,Total Hours,Regular Hours,OT Hours,Hourly Rate,OT Rate,Lunch Deductions,Flags
GR-001,John Smith,Operations,Operator,8.00,8.50,8.00,8.25,7.50,0.00,0.00,40.25,40.25,0.00,22.00,,5,0
GR-002,Jane Doe,Operations,Driver,8.00,8.00,10.00,8.00,8.00,5.00,5.50,52.50,44.00,8.50,20.00,23.48,5,0

,TOTALS,,,,,,,,,,92.75,84.25,8.50,,,,
```

## PDF Layout

Landscape letter size with:
- Company header + pay period
- Employee table: Name, ID, Mon–Sun, Total, Reg, OT, Flags
- Alternating row backgrounds
- Amber left border for flagged employees
- Red left border for zero-hours employees
- Bold totals row with dark background
- Overtime summary section listing each OT employee with rate
- Approval footer (approved by, date, NB ESA compliance note)

---

## Testing

```bash
# With a running API (port 3400):

# 1. Generate + email (or console log if no Resend key)
curl -X POST http://localhost:3400/api/time/approval/2026-03-09/export \
  -H "Cookie: time_session=YOUR_TOKEN"

# 2. Download CSV
curl http://localhost:3400/api/time/approval/2026-03-09/export/download?format=csv \
  -H "Cookie: time_session=YOUR_TOKEN" \
  -o payroll-2026-03-09.csv

# 3. Download PDF
curl http://localhost:3400/api/time/approval/2026-03-09/export/download?format=pdf \
  -H "Cookie: time_session=YOUR_TOKEN" \
  -o payroll-2026-03-09.pdf
```

## Configuration

Set in app_config table:
- `accountant_email` — recipient for payroll exports
- `company_name` — appears in PDF header and email subject

Set in environment:
- `RESEND_API_KEY` — Resend API key for email delivery
- `TIME_MAILER_FROM` — sender address (e.g. noreply@greyrockmaterials.dev)
